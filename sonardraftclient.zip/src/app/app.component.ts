import { Component } from '@angular/core';

import { Apollo } from 'apollo-angular';
import gql from 'graphql-tag';
import { delay } from 'q';
import { Character } from './model/Character';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  characterImageBaseUrl = 'https://ddragon.leagueoflegends.com/cdn/9.20.1/img/champion/';
  title = 'sonardraftclient';
  serverIsAlive = false;
  clientIsRunning = false;
  mockedDraft = null;

  constructor(private apollo: Apollo) {
    this.isAlive();
  }

  toggleClientRunning() {

    this.apollo.query(
      {
        query: gql`
  {
    toggleClientRunning
  }`
      }
    )
      .subscribe(result => {
        this.setClientRunning(result.data['toggleClientRunning']);
      },
        err => {
          this.setClientRunning(false);
        });

  }

  getDraft() {

    if (this.serverIsAlive && this.clientIsRunning) {
      this.apollo.query(
        {
          query: gql`
    {
      draft {
        blue {
          picks{
            name
          }
          banns{
            name
          }
          combos{
            name
            priority
          }
        }
        red {
          picks{
            name
          }
          banns{
            name
          }
          combos{
            name
            priority
          }
        }
      }
    }`
        }
      )
        .subscribe(result => {
          this.mockedDraft = result.data['draft'];
        },
          err => {
            console.log(err);
          });

    }
  }

  async isAlive() {

    while (true) {

      this.apollo.query(
        {
          query: gql`
    {
      isAlive
    }`
        }
      )
        .subscribe(result => {
          this.setAlive(result.data['isAlive']);
        },
          err => {
            this.setAlive(false);
          });

      this.apollo.query(
        {
          query: gql`
        {
          isClientRunning
        }`
        }
      )
        .subscribe(result => {
          this.setClientRunning(result.data['isClientRunning']);
        },
          err => {
            this.setClientRunning(false);
          });


      if (this.clientIsRunning && this.serverIsAlive) {
        this.getDraft();
        await delay(500);
      } else if (this.serverIsAlive) {
        await delay(5000);
      } else {
        await delay(1000);
      }


    }

  }

  getImageUrl(character: Character): string {

    if (character.name === 'None' || character.name === 'Picking') {
      return './assets/character/' + character.name + '.png';
    } else {
      return this.characterImageBaseUrl + character.name + '.png';
    }
  }

  setClientRunning(alive: boolean) {
    this.clientIsRunning = alive;
  }

  setAlive(alive: boolean) {
    this.serverIsAlive = alive;
  }
}
