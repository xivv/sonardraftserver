import { Character } from './Character';

export interface Team {
    picks: Character[];
    banns: Character[];
    combos: Character[];
}
